# EN2H Booking Platform REST API - NestJS Technical Assignment

Welcome to my submission for the Software Engineer Intern (NestJS) position at **EN2H**. This project is a robust, clean, and highly structured Booking Platform REST API built using **NestJS**, **TypeScript**, and **Prisma ORM**.

The platform provides a secure API for administrators to manage services and monitor customer bookings, while allowing public customers to explore and book services without authentication.

---

## 🚀 Key Features Implemented

1. **JWT-Based Authentication**
   - Register and Login endpoints.
   - Standard Passport-JWT guard securing sensitive administrative endpoints.
2. **Service Management (Admin)**
   - CRUD operations: Create, Read, Update, Delete services.
   - Automated duration and price validations via `class-validator`.
3. **Booking Management**
   - Public customer bookings without login.
   - Admin-only routes for viewing, updating booking statuses, and cancelling bookings.
   - Comprehensive query support: **Search** by customer details, **Filter** by booking status, and **Pagination**.
4. **Strict Business Rules**
   - Booking belongs to a valid, active service.
   - Booking dates cannot be in the past.
   - Cancelled bookings cannot be updated to completed.
   - **No duplicates:** Prevents double bookings for the same service, date, and time via database-level unique constraints.
5. **Advanced Features**
   - Global customized exception handling (standardized JSON errors).
   - Dynamic Swagger Interactive Documentation.
   - Full Docker & Docker Compose container configuration.

---

## 📁 Project Structure

This project follows the official NestJS best practices and hexagonal directory structure:

```text
src/
├── app.module.ts            # Root module importing all features
├── main.ts                  # Application entry point & configuration
├── prisma/                  # Prisma module and service for database connection
│   ├── prisma.module.ts
│   └── prisma.service.ts
├── common/                  # Shared utilities, filters, and guards
│   └── filters/
│       └── http-exception.filter.ts # Global error sanitizer
├── auth/                    # JWT Authentication module
│   ├── auth.controller.ts
│   ├── auth.module.ts
│   ├── auth.service.ts
│   ├── jwt-auth.guard.ts
│   ├── jwt.strategy.ts
│   └── dto/
│       ├── login.dto.ts
│       └── register.dto.ts
├── services/                # Service Management module
│   ├── services.controller.ts
│   ├── services.module.ts
│   ├── services.service.ts
│   └── dto/
│       ├── create-service.dto.ts
│       └── update-service.dto.ts
└── bookings/                # Booking Management module
    ├── bookings.controller.ts
    ├── bookings.module.ts
    ├── bookings.service.ts
    └── dto/
        ├── create-booking.dto.ts
        └── update-booking.dto.ts
```

---

## 🛠️ Installation & Setup Instructions

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Docker (optional, for container running)

### Step 1: Clone and Install Dependencies
```bash
# Navigate to project root
cd en2h-booking-api

# Install dependencies
npm install
```

### Step 2: Environment Configuration
Create a `.env` file in the root directory. You can copy the template:
```bash
cp .env.example .env
```

Default configurations are set up to run using SQLite immediately, with zero-setup:
```env
PORT=3000
NODE_ENV=development
DATABASE_URL="file:./dev.db"
JWT_SECRET="en2h_super_secret_jwt_key_change_me"
JWT_EXPIRES_IN="1d"
```

---

## 🗄️ Database Setup

Prisma ORM is utilized for high performance and type-safe queries. 

### Swapping Database Provider (PostgreSQL vs. SQLite)
By default, the project runs on **SQLite** for instant execution. To swap to the preferred **PostgreSQL**:
1. Open `prisma/schema.prisma`.
2. Modify the `datasource db` block:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
3. Update your `.env` file with your PostgreSQL connection string:
   ```env
   DATABASE_URL="postgresql://postgres:password@localhost:5432/en2h_booking?schema=public"
   ```

### Running Migrations
To create and apply the database tables:
```bash
# Generate the Prisma Client
npx prisma generate

# Create and apply migrations (creates the DB file and tables)
npx prisma migrate dev --name init
```

---

## 🏃 Running the Application

### Running Locally
```bash
# Development mode with watch reloading
npm run start:dev

# Production build and run
npm run build
npm run start:prod
```

### Running via Docker
The project includes a multi-stage Docker build and Docker Compose configuration. To run the full system inside containers:
```bash
# Build and spin up the containers
docker-compose up --build -d

# Spin down the containers
docker-compose down
```

---

## 📖 API Documentation (Swagger)

Once the application is running, open your browser and navigate to:
👉 **[http://localhost:3000/api/docs](http://localhost:3000/api/docs)**

This opens an interactive Swagger UI page where you can:
- Explore request/response schemas.
- Test endpoints dynamically.
- Copy mock headers for JWT validation.

---

## 🧠 Assumptions Made

1. **Authentication Scope:** 
   - Public users (customers) do not require accounts or logins. They can view services and create bookings.
   - Managing services (Creating, Updating, Deleting), fetching list of bookings, and updating booking status are administrative tasks protected by standard JWT guards.
2. **Date Format:**
   - Booking dates are processed and stored as standard ISO strings `YYYY-MM-DD` and booking times as `HH:MM` (24-hour format). This ensures consistency and prevents timezone mismatch bugs.
3. **Double Booking Prevention:**
   - A service cannot be booked twice for the same service ID, date, and time slot. This is handled gracefully at the application service tier (with custom error messages) and guarded via a unique database index key.

---

## 🛠️ Future Improvements

- **Email Notifications:** Integrate SendGrid or Nodemailer to send emails when bookings are created, confirmed, or cancelled.
- **Calendar Integrations:** Sync bookings directly with Google Calendar or Outlook Calendar APIs.
- **Role-Based Access Control (RBAC):** Expand authentications to support granular permissions (e.g., Guest, Staff, SuperAdmin).
- **Time-Slot Generation:** Instead of inputting simple string times, generate dynamic available slots based on service duration and staff availability calendars.
- **Unit & Integration Tests:** Add a full Jest test suite targeting controllers and service layers with database mocking.
