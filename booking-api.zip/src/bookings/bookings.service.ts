import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateBookingDto } from './dto/create-booking.dto';
import { BookingStatus, UpdateBookingStatusDto } from './dto/update-booking.dto';

@Injectable()
export class BookingsService {
  constructor(private prisma: PrismaService) {}

  async create(createBookingDto: CreateBookingDto) {
    const { serviceId, bookingDate, bookingTime } = createBookingDto;

    // 1. Business Rule: A booking must belong to an existing service
    const service = await this.prisma.service.findUnique({
      where: { id: serviceId },
    });
    if (!service) {
      throw new NotFoundException(`Service with ID "${serviceId}" does not exist`);
    }

    if (!service.isActive) {
      throw new BadRequestException(`Service "${service.title}" is currently inactive`);
    }

    // 2. Business Rule: Booking dates cannot be in the past
    // Let's check with the date format (YYYY-MM-DD). We compare with the current date (in candidate timezone or UTC).
    const todayStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    if (bookingDate < todayStr) {
      throw new BadRequestException('Booking date cannot be in the past');
    }

    // 3. Business Rule: Prevent duplicate bookings for the same service, date, and time
    const duplicate = await this.prisma.booking.findUnique({
      where: {
        serviceId_bookingDate_bookingTime: {
          serviceId,
          bookingDate,
          bookingTime,
        },
      },
    });
    if (duplicate) {
      throw new ConflictException(
        `This service is already booked at ${bookingTime} on ${bookingDate}. Please choose another time.`,
      );
    }

    // Create the booking
    return this.prisma.booking.create({
      data: {
        customerName: createBookingDto.customerName,
        customerEmail: createBookingDto.customerEmail,
        customerPhone: createBookingDto.customerPhone,
        bookingDate,
        bookingTime,
        status: BookingStatus.PENDING,
        notes: createBookingDto.notes,
        serviceId,
      },
      include: {
        service: true,
      },
    });
  }

  async findAll(search?: string, status?: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;

    // Build the query clauses
    const where: any = {};

    if (status) {
      where.status = status.toUpperCase();
    }

    if (search) {
      where.OR = [
        { customerName: { contains: search } },
        { customerEmail: { contains: search } },
        { customerPhone: { contains: search } },
        { notes: { contains: search } },
      ];
    }

    // Get count and items in parallel
    const [total, items] = await Promise.all([
      this.prisma.booking.count({ where }),
      this.prisma.booking.findMany({
        where,
        include: { service: true },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
    ]);

    return {
      data: items,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const booking = await this.prisma.booking.findUnique({
      where: { id },
      include: { service: true },
    });
    if (!booking) {
      throw new NotFoundException(`Booking with ID "${id}" not found`);
    }
    return booking;
  }

  async updateStatus(id: string, updateBookingStatusDto: UpdateBookingStatusDto) {
    const { status } = updateBookingStatusDto;
    const booking = await this.findOne(id);

    // 4. Business Rule: Cancelled bookings cannot be marked as completed
    if (booking.status === BookingStatus.CANCELLED && status === BookingStatus.COMPLETED) {
      throw new BadRequestException('A cancelled booking cannot be marked as completed');
    }

    return this.prisma.booking.update({
      where: { id },
      data: { status },
      include: { service: true },
    });
  }

  async cancel(id: string) {
    const booking = await this.findOne(id);

    // If it's already cancelled
    if (booking.status === BookingStatus.CANCELLED) {
      return booking;
    }

    return this.prisma.booking.update({
      where: { id },
      data: { status: BookingStatus.CANCELLED },
      include: { service: true },
    });
  }
}
