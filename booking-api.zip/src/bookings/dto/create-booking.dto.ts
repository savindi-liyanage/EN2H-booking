import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsOptional, IsString, Matches } from 'class-validator';

export class CreateBookingDto {
  @ApiProperty({ example: 'John Doe', description: 'Name of the customer' })
  @IsString()
  @IsNotEmpty()
  customerName: string;

  @ApiProperty({ example: 'johndoe@example.com', description: 'Email address of the customer' })
  @IsEmail()
  @IsNotEmpty()
  customerEmail: string;

  @ApiProperty({ example: '+94771234567', description: 'Phone number of the customer' })
  @IsString()
  @IsNotEmpty()
  customerPhone: string;

  @ApiProperty({ example: 'f39a7bb2-60ef-4f2f-b4b6-eb2f4bc362b1', description: 'The service ID this booking is for' })
  @IsString()
  @IsNotEmpty()
  serviceId: string;

  @ApiProperty({ example: '2026-08-15', description: 'Booking date in YYYY-MM-DD format' })
  @IsString()
  @IsNotEmpty()
  @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'bookingDate must be in YYYY-MM-DD format' })
  bookingDate: string;

  @ApiProperty({ example: '14:30', description: 'Booking time in 24-hour HH:MM format' })
  @IsString()
  @IsNotEmpty()
  @Matches(/^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/, { message: 'bookingTime must be in HH:MM (24-hour) format' })
  bookingTime: string;

  @ApiProperty({ example: 'Please send confirmation via WhatsApp if possible.', description: 'Optional customer notes', required: false })
  @IsString()
  @IsOptional()
  notes?: string;
}
