import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';

export enum BookingStatus {
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED',
}

export class UpdateBookingStatusDto {
  @ApiProperty({ example: BookingStatus.CONFIRMED, enum: BookingStatus, description: 'The new status of the booking' })
  @IsEnum(BookingStatus, { message: 'status must be a valid enum value (PENDING, CONFIRMED, CANCELLED, COMPLETED)' })
  @IsNotEmpty()
  status: BookingStatus;
}
