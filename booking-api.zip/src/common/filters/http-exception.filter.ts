import { ExceptionFilter, Catch, ArgumentsHost, HttpException, HttpStatus } from '@nestjs/common';
import { Request, Response } from 'express';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let error = 'Internal Server Error';

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const res: any = exception.getResponse();
      message = typeof res === 'string' ? res : res.message || res.error || message;
      error = typeof res === 'object' && res.error ? res.error : exception.name;
    } else {
      // Log non-http exceptions for debugging purposes
      console.error('Unhandled Exception:', exception);
      
      // Prisma-specific error code translation for cleaner client messages
      if (exception.code) {
        if (exception.code === 'P2002') {
          status = HttpStatus.CONFLICT;
          message = 'A record with duplicate unique fields already exists in the database.';
          error = 'Conflict';
        } else if (exception.code === 'P2025') {
          status = HttpStatus.NOT_FOUND;
          message = 'The requested database record was not found.';
          error = 'Not Found';
        }
      }
    }

    response.status(status).json({
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      error,
      message,
    });
  }
}
