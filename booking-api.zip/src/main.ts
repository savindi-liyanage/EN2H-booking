import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Enable CORS
  app.enableCors();

  // Configure global validation pipe
  // - whitelist: true ensures non-declared properties in DTOs are stripped automatically
  // - transform: true automatically casts request types (e.g., query params to numbers)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    }),
  );

  // Register global HTTP exception filter for consistent error responses
  app.useGlobalFilters(new HttpExceptionFilter());

  // Configure Swagger Documentation
  const config = new DocumentBuilder()
    .setTitle('EN2H Booking Platform API')
    .setDescription(
      'The backend Booking Platform REST API developed for the EN2H Software Engineer Intern position. Allows users to register/login, manage services, and manage bookings.',
    )
    .setVersion('1.0.0')
    .addBearerAuth()
    .build();
    
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  // Serve on port (default 3000)
  const port = process.env.PORT || 3000;
  await app.listen(port);
  console.log(`EN2H Booking Platform API running on http://localhost:${port}`);
  console.log(`Swagger documentation available on http://localhost:${port}/api/docs`);
}

bootstrap();
