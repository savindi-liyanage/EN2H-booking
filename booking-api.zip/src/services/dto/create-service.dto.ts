import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CreateServiceDto {
  @ApiProperty({ example: 'Consultation Session', description: 'The title of the service' })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({ example: 'One-on-one expert backend engineering consultation', description: 'A detailed description of the service' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ example: 60, description: 'The duration of the service in minutes' })
  @IsNumber()
  @Min(5)
  duration: number;

  @ApiProperty({ example: 120.00, description: 'The price of the service' })
  @IsNumber()
  @Min(0)
  price: number;

  @ApiProperty({ example: true, description: 'Whether the service is active and available for bookings', default: true, required: false })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
