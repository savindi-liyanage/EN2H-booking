import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class UpdateServiceDto {
  @ApiPropertyOptional({ example: 'Advanced Consultation', description: 'The title of the service' })
  @IsString()
  @IsOptional()
  title?: string;

  @ApiPropertyOptional({ example: 'Expert NestJS framework guidance', description: 'A detailed description of the service' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ example: 90, description: 'The duration of the service in minutes' })
  @IsNumber()
  @Min(5)
  @IsOptional()
  duration?: number;

  @ApiPropertyOptional({ example: 180.00, description: 'The price of the service' })
  @IsNumber()
  @Min(0)
  @IsOptional()
  price?: number;

  @ApiPropertyOptional({ example: true, description: 'Whether the service is active and available for bookings' })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
